<?php
session_start();
?>
<html>

<head>
    <link rel="STYLESHEET" href="style/index.css?v=<?php echo time(); ?>" type="text/css">
</head>

<body>