<?php
include "header/header_account.php";
?>

<div id="start">
    <h1 class="titlea">Goedendag, <br> welkom op uw account pagina, <br> hier kan u uw reserveringen bekijken en verwijderen</h1>
</div>
<hr>



<?php
include "end/footer.php";
?>