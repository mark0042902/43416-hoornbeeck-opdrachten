<?php
include "header/header_home.php";
include "connection_db/config.php";
?>


<div id="start">
    <h1 class="title">Goedendag, <br> klik op filteren om uw zoekresultaten te filteren</h1>
</div>
<button class="filter">
    <label>Filteren</label>
</button>
<hr class="head">

<div class="houses">
    <table class="table" cellspacing="0" cellpadding="5">
        <tr>
            <td>
                <ul class="photo">foto</ul>
                <ul class="title_p">title</ul>
                <ul class="desc">description</ul>
                <ul class="price">price</ul>
            </td>
        </tr>
    </table>
</div>


<?php
include "end/footer.php";
?>