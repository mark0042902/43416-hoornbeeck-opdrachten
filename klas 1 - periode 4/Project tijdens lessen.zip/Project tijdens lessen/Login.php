<?php
include "header/header_login.php";
include "connection_db/config.php";
?>


<div id="start">
    <h1 class="title">Goedendag, <br> Log hier in om huisjes te kunnen bekijken en boeken</h1>
</div>



<?php
include "end/footer.php";
?>